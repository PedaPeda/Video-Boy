Video Boy 1.0.0 for Linux

Install for your user:   ./install.sh
Install system-wide:     sudo ./install.sh --system
Remove:                  ./uninstall.sh   (or sudo ./uninstall.sh --system)
Run without installing:  ./video-boy

The app opens in its own window using a Chromium-based browser (Chrome, Chromium,
Brave, Edge, Vivaldi) or Firefox. Everything runs locally; nothing is uploaded.
Command-line converter: video-boy-cli (needs python3, python3-numpy and ffmpeg).
https://github.com/PedaPeda/Video-Boy
